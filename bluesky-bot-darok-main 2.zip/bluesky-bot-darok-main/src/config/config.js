import dotenv from 'dotenv';
dotenv.config();

export const API_SERVICE_URL = 'https://bsky.social';
